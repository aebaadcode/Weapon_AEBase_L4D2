//we need the gun add-on for this, so force it to load
%error = ForceRequiredAddOn("Weapon_Shotguns");

if(%error == $Error::AddOn_Disabled)
{
   //Some idiot disabled it! Mother @#$%er!
   error("ERROR: Weapon_AutoShotgun - required add-on Weapon_Shotguns not found");
}
else
{
   exec("./Support_AmmoGuns.cs");
   exec("./Weapon_AutoShotgun.cs");  
   exec("./Weapon_SPAS12.cs");  
}
