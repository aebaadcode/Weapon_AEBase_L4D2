//we need the gun add-on for this, so force it to load
%error = ForceRequiredAddOn("Weapon_Gun");

if(%error == $Error::AddOn_Disabled)
{
   //we don't have the gun, so we're screwed
   error("ERROR: Weapon_Hunting_Shotgun - required add-on Weapon_Gun not found");
}
else
{
   exec("./Support_AmmoGuns.cs");
   exec("./Weapon_Hunting_Shotgun.cs");  
   exec("./Weapon_Chrome_Shotgun.cs");  
}
