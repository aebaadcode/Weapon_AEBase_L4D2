
//we need the gun add-on for this, so force it to load
%error = ForceRequiredAddOn("Weapon_Gun");

//Idiot Test
//If (0 == 1)
//{
if(%error == $Error::AddOn_NotFound)
{
   //we don't have the gun, so we're screwed
   error("ERROR: Weapon_CombatRifle - required add-on Weapon_Gun not found");
}
else
{
   exec("./Weapon_FNSCAR.cs"); 
   exec("./Support_AmmoGuns.cs"); 
}
//}